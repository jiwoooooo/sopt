package org.sopt;

public class Main {

    final static double PI = 3.14;

    static int a;

    public static void main(String[] args) {
	// write your code here
        a = 1;
    }

    private static void dfs(final int x) {

    }
}
