package org.sopt;

/**
 * Created by ds on 2018-10-11.
 */

public class User {
    private String name;

    public User(final String name) {
        this.name = name;
    }
}
