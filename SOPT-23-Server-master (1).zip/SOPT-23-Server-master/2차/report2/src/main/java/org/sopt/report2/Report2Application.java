package org.sopt.report2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Report2Application {

    public static void main(String[] args) {
        SpringApplication.run(Report2Application.class, args);
    }
}
