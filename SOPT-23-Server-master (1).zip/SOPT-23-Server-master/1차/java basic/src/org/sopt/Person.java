package org.sopt;

/**
 * Created by ds on 2018-09-25.
 */

public class Person {
    private String name;

    public Person(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
