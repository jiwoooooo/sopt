package org.sopt;

/**
 * Created by ds on 2018-09-25.
 */

public class UserServiceImpl  implements UserInterface{


    @Override
    public void getInfo() {

    }

    @Override
    public String getDept() {
        return null;
    }

    @Override
    public void setState(boolean state) {

    }
}
