package org.sopt;

/**
 * Created by ds on 2018-09-25.
 */


public class DefaultRes<T, S, U, A> {

    private T responseData;

    private S asd;



    public DefaultRes(final T responseData) {
        this.responseData = responseData;
    }
}
