package org.sopt;

/**
 * Created by ds on 2018-09-25.
 */
public interface Interface2 {
}
