//package org.sopt.seminar3.lombok;
//
//import org.sopt.seminar3.model.DefaultRes;
//import org.sopt.seminar3.model.User;
//import org.sopt.seminar3.service.UserService;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
///**
// * Created by ds on 2018-10-19.
// */
//
//@Service(value = "UserServiceImpl2")
//public class UserServiceImpl2 implements UserService {
//
//    @Override
//    public DefaultRes<List<User>> findAll() {
//        return null;
//    }
//
//    @Override
//    public DefaultRes<User> findByUserIdx(int userIdx) {
//        return null;
//    }
//
//    @Override
//    public DefaultRes<User> save(User user) {
//        return null;
//    }
//
//    @Override
//    public DefaultRes<User> update(int userIdx, User user) {
//        return null;
//    }
//
//    @Override
//    public DefaultRes<User> deleteByUserIdx(int userIdx) {
//        return null;
//    }
//}
