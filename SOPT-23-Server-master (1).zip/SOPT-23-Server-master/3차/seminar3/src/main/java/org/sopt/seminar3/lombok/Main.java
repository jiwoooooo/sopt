package org.sopt.seminar3.lombok;

/**
 * Created by ds on 2018-10-22.
 */

public class Main {

    public static void main(String... args) {

    }
}
