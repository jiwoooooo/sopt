package org.sopt.seminar3.lombok;

/**
 * Created by ds on 2018-10-22.
 */

/**
 * Default
 */

public class Test {
    private int userIdx;
    private String name;
    private String email;

//    public Test(final int userIdx) {
//        this.userIdx = userIdx;
//    }
}
