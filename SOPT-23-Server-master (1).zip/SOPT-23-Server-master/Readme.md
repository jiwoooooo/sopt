# SOPT-23-Server

![SOPT_23_COLOR_LOGO](https://github.com/bghgu/SOPT-23-Server/blob/master/SOPT_23_COLOR_LOGO.png)

| 차수 | 내용                                  |
| ---- | ------------------------------------- |
| 1차  | JAVA 기초, Spring boot 시작하기       |
| 2차  | Spring Presentation Layer, Tomcat     |
| 3차  | Spring business Logic Layer, AWS EC2  |
| 4차  | MySQL, Mybatis, AWS RDS               |
| 5차  | File Upload, AWS S3, Interceptor, JWT |
| 6차  | URI, REST API 설계 및 구현            |
| 7차  | 클라이언트 연동 세미나                |
| 8차  | Spring Data JPA 맛보기, Q&A(보충)     |

